package com.example.ecommarce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
