import 'package:ecommarce/data/models/product_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/services/product_service.dart';

class HomeController extends GetxController {
  var productList = <ProductModel>[].obs;
  var cartList = <ProductModel>[].obs;
  var isFavourite = false.obs;

  @override
  void onInit() {
    getProduct();
    super.onInit();
  }

  void getProduct() {
    ProductService().getProduct(onSuccess: (data) {
      productList.assignAll(data);
    }, onError: (error) {
      debugPrint('------------- Product loading failed $error');
    });
  }

  void addToCart({required ProductModel productModel}) {
    cartList.add(productModel);
  }

  /// [tag] 1 for increase 2 for decrease
  void updateQuantity({required int id, required int tag}) {

    final ProductModel productModel = cartList.where((e) => e.id == id).first;
    tag == 1
        ? productModel.quantity = productModel.quantity! + 1
        : productModel.quantity! > 1
        ? productModel.quantity = productModel.quantity! - 1
        : cartList.remove(productModel);

    update();
  }
}
