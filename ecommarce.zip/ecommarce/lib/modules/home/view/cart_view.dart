import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommarce/modules/home/controller/home_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:math' as math;

import '../../../data/resources/colors.dart';
import '../../../widgets/drawer/drawer_widget.dart';

class CartView extends GetView<HomeController> {
  const CartView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      drawer: AppDrawer(),
      drawerEnableOpenDragGesture: false,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        elevation: 0,
        leading: Builder(builder: (context) {
          return GestureDetector(
            onTap: () {
              Scaffold.of(context).openDrawer();
            },
            child: const Icon(
              Icons.segment,
              size: 35,
            ),
          );
        }),
        title: Text(
          'Cart',
          style: GoogleFonts.roboto(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: SvgPicture.asset(
              'assets/filter.svg',
              height: 24,
              width: 24,
            ),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: Obx(() {
          return ListView.builder(
              itemCount: controller.cartList.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10.0),
                  child: IntrinsicHeight(
                    child: Container(
                      width: width,
                      padding: const EdgeInsets.all(8.0),
                      decoration: BoxDecoration(
                          color: AppColors.productBg,
                          borderRadius: BorderRadius.circular(20)),
                      child: Row(
                        children: [
                          Stack(
                            clipBehavior: Clip.none,
                            fit: StackFit.passthrough,
                            children: [
                              Transform.rotate(
                                angle: (math.pi / 180) * -15,
                                child: Container(
                                  height: 80,
                                  width: 80,
                                  decoration: BoxDecoration(
                                      color: AppColors.itemBg,
                                      borderRadius: BorderRadius.circular(15)),
                                ),
                              ),
                              Positioned.fill(
                                  child: CachedNetworkImage(
                                imageUrl:
                                    controller.cartList[index].image.toString(),
                                progressIndicatorBuilder:
                                    (context, url, downloadProgress) =>
                                        CircularProgressIndicator(
                                            value: downloadProgress.progress),
                                errorWidget: (context, url, error) =>
                                    const Icon(
                                  Icons.error_outline,
                                  size: 26,
                                ),
                                width: 120,
                                height: 100,
                              ))
                            ],
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: Text(
                                controller.cartList[index].title.toString(),
                                style: GoogleFonts.roboto(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.black)),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Text("\$ ${controller.cartList[index].price}",
                                  style: GoogleFonts.roboto(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color: AppColors.priceColor)),
                              GetBuilder<HomeController>(builder: (cartController) {
                                return Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    GestureDetector(
                                      onTap:(){
                                        cartController.updateQuantity(
                                            id: cartController.cartList[index].id!, tag: 2);
                                      },
                                      child: Card(
                                        elevation: 3,
                                        shape: const CircleBorder(),
                                        child: Container(
                                          padding: const EdgeInsets.all(5),
                                          decoration: const BoxDecoration(
                                              color: AppColors.cartBg,
                                              shape: BoxShape.circle),
                                          child: const Icon(
                                            Icons.remove,
                                            size: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 5.0),
                                      child: Text(
                                          "${cartController.cartList[index].quantity}",
                                          style: GoogleFonts.roboto(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16,
                                              color: AppColors.priceColor)),
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        cartController.updateQuantity(id: cartController.cartList[index].id!, tag: 1);
                                      },
                                      child: Card(
                                        elevation: 1,
                                        shape: const CircleBorder(),
                                        child: Container(
                                          padding: const EdgeInsets.all(5),
                                          decoration: const BoxDecoration(
                                              color: AppColors.cartBg,
                                              shape: BoxShape.circle),
                                          child: const Icon(
                                            Icons.add,
                                            size: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              })
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              });
        }),
      ),
    );
  }
}
