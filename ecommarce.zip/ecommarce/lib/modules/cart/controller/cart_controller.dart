import 'package:get/get.dart';

class CartController extends GetxController{

}