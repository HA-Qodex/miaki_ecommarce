

import 'package:ecommarce/modules/home/controller/home_controller.dart';
import 'package:get/get.dart';

import '../controller/cart_controller.dart';

class CartBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => CartController());
  }
}