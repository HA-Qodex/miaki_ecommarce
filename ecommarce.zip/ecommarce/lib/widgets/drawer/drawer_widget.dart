import 'package:ecommarce/widgets/drawer/drawer_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../data/resources/colors.dart';
import '../../routes/app_pages.dart';

class AppDrawer extends StatelessWidget {
  AppDrawer({Key? key}) : super(key: key);

  final navigationController = Get.put(NavigationController());

  @override
  Widget build(BuildContext context) {
    final safeArea = EdgeInsets.only(top: MediaQuery.of(context).viewPadding.top);
    return  SizedBox(
        width: MediaQuery.of(context).size.width * 0.65,
        child: Drawer(
          child: Container(
            color: Colors.white,
            child: Column(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10).add(safeArea),
                  width: double.infinity,
                  child: Center(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Container(
                              height: 80,
                              width: 80,
                              padding: const EdgeInsets.all(5.0),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: AppColors.productBg, width: 2),
                              ),
                              child:
                                 const FlutterLogo()
                            ),
                          ],
                        ),
                        const Text(
                          "Huzaifa Ahmed",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                        const Text(
                          "+8801700000000",
                          style: TextStyle(
                              fontSize: 16, color: Colors.black),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      ],
                    ),
                  ),
                ),
                Divider(color: Colors.grey.shade400, thickness: 1,),
                Expanded(
                  child: GetX<NavigationController>(
                    builder: (controller) {
                      return ListView.builder(
                          padding: EdgeInsets.zero,
                          physics: const AlwaysScrollableScrollPhysics(),
                          itemCount: controller.items.length,
                          itemBuilder: (context, index) {
                            return buildMenuItem(
                                text: controller.items[index]
                                    .title,
                                icon: controller.items[index]
                                    .icon,
                                onClick: () {
                                  if(controller.selectedIndex.value == index){
                                    Get.back();
                                  } else {
                                    controller.selectedIndex.value = index;
                                    controller.selectedItems(
                                        index);
                                  }
                                },
                                context: context,
                                index: index,
                                selectedIndex: controller.selectedIndex.value
                            );
                          });
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      );
  }

  Widget buildMenuItem(
      {required String text,
      required IconData icon,
      VoidCallback? onClick,
      required BuildContext context,
      required int index,
      required int selectedIndex}) {
    return GestureDetector(
      onTap: onClick,
      child: Container(
          height: 50,
          width: MediaQuery.of(context).size.width,
          padding: const EdgeInsets.only(left: 5),
          margin: const EdgeInsets.only(left: 15),
          decoration: BoxDecoration(
            borderRadius: selectedIndex == index
                ? const BorderRadius.only(
                    topLeft: Radius.circular(10),
                    bottomLeft: Radius.circular(10))
                : null,
            color: selectedIndex == index
                ? AppColors.itemBg.withOpacity(0.4)
                : Colors.transparent,
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: selectedIndex == index
                    ? Colors.black
                    : AppColors.primary.withOpacity(0.8),
              ),
              const SizedBox(
                width: 30,
              ),
              Text(
                text,
                style: GoogleFonts.lato(color: Colors.black, fontSize: 16),
              ),
            ],
          )),
    );
  }
}
