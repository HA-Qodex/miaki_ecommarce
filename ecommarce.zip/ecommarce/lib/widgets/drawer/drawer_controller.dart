
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../routes/app_pages.dart';
import 'model.dart';

class NavigationController extends GetxController{

  var selectedIndex = 0.obs;

  void selectedItems(int index){

    switch (index) {
      case 0:
        Get.toNamed(Routes.HOME);
        break;
      case 1:
        Get.toNamed(Routes.CART);
        break;
      default: Get.toNamed(Routes.HOME);
    }

  }

  var items = [
    DrawerItem(title: "Home", icon: Icons.home),
    DrawerItem(title: "Cart", icon: Icons.shopping_cart_outlined),
  ].obs;

}