
import 'package:flutter/material.dart';

class DrawerItem{
  final String title;
  final IconData icon;

  DrawerItem({required this.title, required this.icon});
}

// enum MenuType{Home, Tour_Plan, Visit, Order, Collection, Attendance, Competitor_Activity, Customer_Stock,
//
// };